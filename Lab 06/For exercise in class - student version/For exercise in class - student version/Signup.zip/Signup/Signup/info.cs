﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Signup
{
    internal class info
    {
        public int ID { set; get; }
        public string? FName { set; get; }
        public string? LName { set; get; }
        public string? Sex { set; get; }
        public string? Bdate { set; get; }
        public string? Email { set; get; }
        public string? Occup { set; get; }

    }
}
